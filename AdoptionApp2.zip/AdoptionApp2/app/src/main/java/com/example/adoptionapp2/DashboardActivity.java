package com.example.adoptionapp2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DashboardActivity extends AppCompatActivity {

    private Button dogsButton, catsButton;
    private ImageButton addButton, quizButton;
    private RecyclerView recyclerView;
    private AnimalAdapter animalAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dogs_dashboard);  // Link the XML layout for Dogs Dashboard

        // Initialize the buttons and RecyclerView
        dogsButton = findViewById(R.id.dogsButton);
        catsButton = findViewById(R.id.catsButton);
        addButton = findViewById(R.id.addButton);  // Add button
        quizButton = findViewById(R.id.quizButton);  // Quiz button
        recyclerView = findViewById(R.id.recyclerView);  // RecyclerView to display animal cards

        // Set up RecyclerView (LinearLayout for displaying animal cards in rows)
        recyclerView.setLayoutManager(new LinearLayoutManager(this));  // Display cards in rows

        // Fetch dogs from the database using DatabaseHelper
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        List<Animal> animals = dbHelper.getAnimalsByCategory("Dog");  // Get only dogs from the database

        // Check if animals were fetched correctly
        if (animals != null && !animals.isEmpty()) {
            animalAdapter = new AnimalAdapter(this, animals, animal -> {
                // Handle item click event
                Intent i = new Intent(DashboardActivity.this, AnimalDetailActivity.class);
                i.putExtra("petId", animal.getId());
                i.putExtra("petName", animal.getName());
                i.putExtra("petDetails", animal.getGender() + ", " + animal.getAge() + " yrs");
                i.putExtra("petDescription", animal.getDescription());
                i.putExtra("petImage", animal.getImage());
                i.putExtra("petNeutered", animal.getNeutered());
                i.putExtra("petVaccinated", animal.getVaccinated());
                startActivity(i);
            });
            recyclerView.setAdapter(animalAdapter);
        } else {
            Toast.makeText(this, "No animals available", Toast.LENGTH_SHORT).show();
            Log.d("DashboardActivity", "No animals in the database or failed to fetch.");
        }

        // Set up Cats button click listener to navigate to Cats Dashboard
        catsButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, CatsDashboardActivity.class);
            startActivity(intent);
        });

        // Set up Add button click listener to navigate to AnimalInputActivity
        addButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, AnimalInputActivity.class);
            startActivity(intent);
        });

        // Set up the Quiz button click listener
        quizButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, QuizActivity.class);
            startActivity(intent);  // Start the QuizActivity
        });
    }
}
