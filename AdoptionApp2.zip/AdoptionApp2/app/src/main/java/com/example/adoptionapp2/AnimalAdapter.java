package com.example.adoptionapp2;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AnimalAdapter extends RecyclerView.Adapter<AnimalAdapter.AnimalViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(Animal animal);
    }

    private final Context context;
    private final List<Animal> animalList;
    private final OnItemClickListener listener;

    public AnimalAdapter(Context context, List<Animal> animalList, OnItemClickListener listener) {
        this.context = context;
        this.animalList = animalList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public AnimalViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_animal_card, parent, false);
        return new AnimalViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AnimalViewHolder holder, int position) {
        Animal a = animalList.get(position);

        holder.petName.setText(a.getName());
        holder.petDetails.setText(a.getGender() + ", " + a.getAge() + " yrs");

        String img = a.getImage(); // store URI/filepath in DB
        if (img != null && !img.isEmpty()) {
            try {
                // Check if it's a file path or URI
                if (img.startsWith("/")) {
                    // It's a file path
                    holder.petImage.setImageURI(Uri.fromFile(new java.io.File(img)));
                } else {
                    // It's a URI
                    holder.petImage.setImageURI(Uri.parse(img));
                }
            } catch (Exception e) {
                holder.petImage.setImageResource(R.drawable.ic_default_pet_image);
            }
        } else {
            holder.petImage.setImageResource(R.drawable.ic_default_pet_image);
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onItemClick(a);
        });
    }

    @Override
    public int getItemCount() {
        return (animalList == null) ? 0 : animalList.size();
    }

    static class AnimalViewHolder extends RecyclerView.ViewHolder {
        ImageView petImage;
        TextView  petName;
        TextView  petDetails;

        AnimalViewHolder(@NonNull View itemView) {
            super(itemView);
            petImage   = itemView.findViewById(R.id.petImage);
            petName    = itemView.findViewById(R.id.petName);
            petDetails = itemView.findViewById(R.id.petDetails);
        }
    }
}