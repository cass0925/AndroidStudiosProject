package com.example.adoptionapp2;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Define database name and version
    private static final String DATABASE_NAME = "adoption_database2.db";
    private static final int DATABASE_VERSION = 2;

    // Constructor
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // onCreate method is called when the database is created
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create User Table
        String createUserTable = "CREATE TABLE IF NOT EXISTS User (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT NOT NULL, " +
                "phone_number INTEGER NOT NULL, " +
                "address TEXT NOT NULL, " +
                "email TEXT NOT NULL UNIQUE, " +
                "password TEXT NOT NULL, " +
                "registration_date DATETIME DEFAULT CURRENT_TIMESTAMP, " +
                "animal_compatibility INTEGER);";

        // Create Animal Table
        String createAnimalTable = "CREATE TABLE IF NOT EXISTS animal (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT NOT NULL, " +
                "age INTEGER NOT NULL, " +
                "gender TEXT NOT NULL, " +
                "category TEXT, " +
                "neutered TEXT, " +
                "vaccinated TEXT, " +
                "description TEXT, " +
                "image TEXT, " +
                "user_id INTEGER, " +
                "created_at DATETIME DEFAULT CURRENT_TIMESTAMP, " +
                "FOREIGN KEY(user_id) REFERENCES User(id));";

        // Create Adoption Request Table
        String createAdoptionRequestTable = "CREATE TABLE IF NOT EXISTS AdoptionRequest (" +
                "request_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "animal_id INTEGER NOT NULL, " +
                "user_id INTEGER NOT NULL, " +
                "request_date DATETIME DEFAULT CURRENT_TIMESTAMP, " +
                "status TEXT NOT NULL, " +
                "FOREIGN KEY(user_id) REFERENCES User(id), " +
                "FOREIGN KEY(animal_id) REFERENCES animal(id));";

        // Execute the SQL statements to create the tables
        db.execSQL(createUserTable);
        db.execSQL(createAnimalTable);
        db.execSQL(createAdoptionRequestTable);
    }

    // onUpgrade method is called when the database version is upgraded
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS User");
        db.execSQL("DROP TABLE IF EXISTS animal");
        db.execSQL("DROP TABLE IF EXISTS AdoptionRequest");
        onCreate(db);  // Recreate the tables
    }

    // Method to insert a new user into the 'User' table
    public long insertUser(String name, int phoneNumber, String address, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("phone_number", phoneNumber);
        values.put("address", address);
        values.put("email", email);
        values.put("password", password);

        long result = db.insert("User", null, values);
        db.close();
        return result;
    }

    // Method to validate user login credentials
    public boolean validateUserLogin(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM User WHERE email = ? AND password = ?";
        Cursor cursor = db.rawQuery(query, new String[]{email, password});

        boolean isValid = cursor.moveToFirst();
        cursor.close();
        return isValid;
    }

    // Method to get user ID by email
    public int getUserIdByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT id FROM User WHERE email = ?";
        Cursor cursor = db.rawQuery(query, new String[]{email});

        int userId = -1;
        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range")
            int userIdValue = cursor.getInt(cursor.getColumnIndex("id"));
            userId = userIdValue;
        }
        cursor.close();
        return userId;
    }

    // Method to insert a new animal into the 'animal' table
    public long insertAnimal(String name, int age, String gender, String category, String description, String image, String neutered, String vaccinated, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("age", age);
        values.put("gender", gender);
        values.put("category", category);
        values.put("description", description);
        values.put("image", image);
        values.put("neutered", neutered);
        values.put("vaccinated", vaccinated);
        values.put("user_id", userId);

        long result = db.insert("animal", null, values);
        db.close();
        return result;
    }

    // Method to fetch all animals from the 'animal' table
    public List<Animal> getAllAnimals() {
        List<Animal> animals = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM animal";  // Ensure this query matches the table structure
        Cursor cursor = db.rawQuery(query, null);

        // Check if cursor is not null and contains data
        if (cursor != null && cursor.moveToFirst()) {
            do {
                // Ensure the column indices are correct
                @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex("id"));
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex("name"));
                @SuppressLint("Range") int age = cursor.getInt(cursor.getColumnIndex("age"));
                @SuppressLint("Range") String gender = cursor.getString(cursor.getColumnIndex("gender"));
                @SuppressLint("Range") String category = cursor.getString(cursor.getColumnIndex("category"));
                @SuppressLint("Range") String description = cursor.getString(cursor.getColumnIndex("description"));
                @SuppressLint("Range") String image = cursor.getString(cursor.getColumnIndex("image"));
                @SuppressLint("Range") String neutered = cursor.getString(cursor.getColumnIndex("neutered"));
                @SuppressLint("Range") String vaccinated = cursor.getString(cursor.getColumnIndex("vaccinated"));

                // Create Animal object and add it to the list
                Animal animal = new Animal(id, name, age, gender, category, description, image, neutered, vaccinated);
                animals.add(animal);

            } while (cursor.moveToNext());  // Move to the next row if it exists
        }
        cursor.close();  // Don't forget to close the cursor to prevent memory leaks
        return animals;
    }

    public List<Animal> getAnimalsByCategory(String categoryFilter) {
        List<Animal> animals = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM animal WHERE category = ?";
        Cursor cursor = db.rawQuery(query, new String[]{categoryFilter});

        if (cursor != null && cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex("id"));
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex("name"));
                @SuppressLint("Range") int age = cursor.getInt(cursor.getColumnIndex("age"));
                @SuppressLint("Range") String gender = cursor.getString(cursor.getColumnIndex("gender"));
                @SuppressLint("Range") String category = cursor.getString(cursor.getColumnIndex("category"));
                @SuppressLint("Range") String description = cursor.getString(cursor.getColumnIndex("description"));
                @SuppressLint("Range") String image = cursor.getString(cursor.getColumnIndex("image"));
                @SuppressLint("Range") String neutered = cursor.getString(cursor.getColumnIndex("neutered"));
                @SuppressLint("Range") String vaccinated = cursor.getString(cursor.getColumnIndex("vaccinated"));

                Animal animal = new Animal(id, name, age, gender, category, description, image, neutered, vaccinated);
                animals.add(animal);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return animals;
    }

    // Method to insert a new adoption request
    public long insertAdoptionRequest(int animalId, int userId, String status) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("animal_id", animalId);
        values.put("user_id", userId);
        values.put("status", status);

        long result = db.insert("AdoptionRequest", null, values);
        db.close();
        return result;
    }

    // Method to get user email by user ID
    public String getUserEmail(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT email FROM User WHERE id = ?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});

        String email = "";
        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range")
            String emailValue = cursor.getString(cursor.getColumnIndex("email"));
            email = emailValue;
        }
        cursor.close();
        return email;
    }

    // Method to get pet owner's user ID by animal ID
    public int getPetOwnerId(int animalId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT user_id FROM animal WHERE id = ?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(animalId)});

        int ownerId = -1;
        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range")
            int ownerIdValue = cursor.getInt(cursor.getColumnIndex("user_id"));
            ownerId = ownerIdValue;
        }
        cursor.close();
        return ownerId;
    }
}
