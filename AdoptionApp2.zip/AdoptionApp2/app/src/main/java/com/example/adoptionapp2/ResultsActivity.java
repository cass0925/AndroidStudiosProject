package com.example.adoptionapp2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ResultsActivity extends AppCompatActivity {

    private TextView resultTextView;
    private Button okButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        // Get the result message passed from QuizActivity
        String resultMessage = getIntent().getStringExtra("resultMessage");

        // Initialize the TextView and set the result message
        resultTextView = findViewById(R.id.resultTextView);
        resultTextView.setText(resultMessage);

        // Initialize the "OK" button and set the click listener
        okButton = findViewById(R.id.okButton);
        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to navigate to RegisterActivity
                Intent intent = new Intent(ResultsActivity.this, DashboardActivity.class);
                startActivity(intent);  // Start RegisterActivity
            }
        });
    }
}
