package com.example.adoptionapp2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.CheckBox;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;


import androidx.appcompat.app.AppCompatActivity;

public class AnimalInputActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private ImageView imageViewAnimal;
    private Button btnUploadImage;
    private Button btnSubmit;
    private ImageButton homeButton;  // Home button to navigate to Dashboard
    private ImageButton quizButton;  // Quiz button to navigate to the quiz page

    // Declare Spinners for Gender and Category
    private Spinner genderSpinner, categorySpinner;
    private EditText editTextName, editTextAge, editTextDescription;
    private CheckBox checkBoxSpayed, checkBoxVaccine;
    private Uri selectedImageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal_input);  // Reference your layout

        // Initialize views
        imageViewAnimal = findViewById(R.id.imageViewAnimal);
        btnUploadImage = findViewById(R.id.btnUploadImage);
        btnSubmit = findViewById(R.id.btnSubmit);
        homeButton = findViewById(R.id.homeButton);  // Initialize Home button
        quizButton = findViewById(R.id.quizButton);  // Initialize Quiz button

        // Initialize EditText fields
        editTextName = findViewById(R.id.editTextName);
        editTextAge = findViewById(R.id.editTextAge);
        editTextDescription = findViewById(R.id.editTextDescription);
        checkBoxSpayed = findViewById(R.id.checkBoxSpayed);
        checkBoxVaccine = findViewById(R.id.checkBoxVaccine);

        // Initialize Spinners for Gender and Category
        genderSpinner = findViewById(R.id.spinnerGender);
        categorySpinner = findViewById(R.id.spinnerCategory);

        // Set up Spinner for Gender
        ArrayAdapter<CharSequence> genderAdapter = ArrayAdapter.createFromResource(
                this, R.array.gender_options, android.R.layout.simple_spinner_item);
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        genderSpinner.setAdapter(genderAdapter);

        // Set up Spinner for Category
        ArrayAdapter<CharSequence> categoryAdapter = ArrayAdapter.createFromResource(
                this, R.array.category_options, android.R.layout.simple_spinner_item);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(categoryAdapter);

        // Check permissions before opening the file chooser
        checkPermissions();
        // Set up image upload button click listener
        btnUploadImage.setOnClickListener(v -> openFileChooser());

        // Set up submit button click listener
        btnSubmit.setOnClickListener(v -> submitAnimal());

        // Set up the "Home" button click listener
        homeButton.setOnClickListener(v -> {
            // Navigate to the DashboardActivity
            Intent intent = new Intent(AnimalInputActivity.this, DashboardActivity.class);
            startActivity(intent);  // Start the DashboardActivity
            finish();  // Close AnimalInputActivity so the user can't go back to it
        });

        // Set up the "Quiz" button click listener
        quizButton.setOnClickListener(v -> {
            // Navigate to the QuizActivity
            Intent intent = new Intent(AnimalInputActivity.this, QuizActivity.class);
            startActivity(intent);  // Start the QuizActivity
            finish();  // Close AnimalInputActivity so the user can't go back to it
        });
    }

    // Check permissions before proceeding with file picking
    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // For Android 13 and above
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_MEDIA_IMAGES},
                        1); // You can replace 1 with any request code you prefer
            }
        } else {
            // For older Android versions (less than Android 13)
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        1); // You can replace 1 with any request code you prefer
            }
        }
    }

    // This function is called when the user clicks the upload button
    private void openFileChooser() {
        // Create an intent to open the file picker
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        // Allow the user to select an image
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    // Handle the result of the image selection (when the user picks an image)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            selectedImageUri = data.getData();  // Get the URI of the selected image

            try {
                // Convert URI to Bitmap
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImageUri);
                // Display the image in the ImageView
                imageViewAnimal.setImageBitmap(bitmap);
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void submitAnimal() {
        // Get values from form
        String name = editTextName.getText().toString().trim();
        String ageStr = editTextAge.getText().toString().trim();
        String gender = genderSpinner.getSelectedItem().toString();
        String category = categorySpinner.getSelectedItem().toString();
        String description = editTextDescription.getText().toString().trim();
        String neutered = checkBoxSpayed.isChecked() ? "Yes" : "No";
        String vaccinated = checkBoxVaccine.isChecked() ? "Yes" : "No";
        String imagePath = "";
        if (selectedImageUri != null) {
            // Copy image to app storage so it persists
            imagePath = copyImageToStorage(selectedImageUri);
            if (imagePath.isEmpty()) {
                imagePath = selectedImageUri.toString(); // Fallback to URI if copy fails
            }
        }

        // Simple validation
        if (name.isEmpty()) {
            Toast.makeText(this, "Please enter animal name", Toast.LENGTH_SHORT).show();
            return;
        }
        if (ageStr.isEmpty()) {
            Toast.makeText(this, "Please enter age", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int age = Integer.parseInt(ageStr);
            int userId = 1; // Default user ID, you can change this later

            // Save to database
            DatabaseHelper dbHelper = new DatabaseHelper(this);
            long result = dbHelper.insertAnimal(name, age, gender, category, description, imagePath, neutered, vaccinated, userId);

            if (result != -1) {
                Toast.makeText(this, "Animal added successfully!", Toast.LENGTH_SHORT).show();
                // Go back to dashboard
                Intent intent = new Intent(this, DashboardActivity.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Failed to add animal", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid age", Toast.LENGTH_SHORT).show();
        }
    }

    private String copyImageToStorage(Uri imageUri) {
        try {
            // Create images directory in app storage
            File imagesDir = new File(getFilesDir(), "images");
            if (!imagesDir.exists()) {
                imagesDir.mkdirs();
            }

            // Create unique filename
            String fileName = "image_" + System.currentTimeMillis() + ".jpg";
            File imageFile = new File(imagesDir, fileName);

            // Copy image from URI to app storage
            InputStream inputStream = getContentResolver().openInputStream(imageUri);
            FileOutputStream outputStream = new FileOutputStream(imageFile);

            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }

            inputStream.close();
            outputStream.close();

            return imageFile.getAbsolutePath();
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }
}
