package com.example.adoptionapp2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CatsDashboardActivity extends AppCompatActivity {

    private Button dogsButton, catsButton;
    private ImageButton homeButton, addButton, quizButton;
    private RecyclerView catRecyclerView;
    private AnimalAdapter animalAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cats_dashboard);  // Link the XML layout for Cats Dashboard

        // Initialize the buttons
        dogsButton = findViewById(R.id.dogsButton);
        catsButton = findViewById(R.id.catsButton);
        homeButton = findViewById(R.id.homeButton);
        addButton = findViewById(R.id.addButton);
        quizButton = findViewById(R.id.quizButton);
        catRecyclerView = findViewById(R.id.catRecyclerView);

        catRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadCats();

        // Set up Dogs button click listener to navigate to Dogs Dashboard
        dogsButton.setOnClickListener(v -> {
            Intent intent = new Intent(CatsDashboardActivity.this, DashboardActivity.class);
            startActivity(intent);
        });

        catsButton.setOnClickListener(v -> {
            // Already on cats screen, no action needed
        });

        // Set up Add button click listener to navigate to AnimalInputActivity
        addButton.setOnClickListener(v -> {
            Intent intent = new Intent(CatsDashboardActivity.this, AnimalInputActivity.class);
            startActivity(intent);
        });

        homeButton.setOnClickListener(v -> {
            Intent intent = new Intent(CatsDashboardActivity.this, DashboardActivity.class);
            startActivity(intent);
        });

        // Set up the Quiz button's click listener
        quizButton.setOnClickListener(v -> {
            Intent intent = new Intent(CatsDashboardActivity.this, QuizActivity.class);
            startActivity(intent);
        });
    }

    private void loadCats() {
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        List<Animal> catList = dbHelper.getAnimalsByCategory("Cat");

        if (catList != null && !catList.isEmpty()) {
            animalAdapter = new AnimalAdapter(this, catList, animal -> {
                Intent i = new Intent(CatsDashboardActivity.this, AnimalDetailActivity.class);
                i.putExtra("petId", animal.getId());
                i.putExtra("petName", animal.getName());
                i.putExtra("petDetails", animal.getGender() + ", " + animal.getAge() + " yrs");
                i.putExtra("petDescription", animal.getDescription());
                i.putExtra("petImage", animal.getImage());
                i.putExtra("petNeutered", animal.getNeutered());
                i.putExtra("petVaccinated", animal.getVaccinated());
                startActivity(i);
            });
            catRecyclerView.setAdapter(animalAdapter);
        } else {
            Toast.makeText(this, "No cats available", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadCats();
    }
}