package com.example.adoptionapp2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class QuizActivity extends AppCompatActivity {

    private int currentQuestionIndex = 0;
    private String[] quizQuestions;
    private String[][] quizOptions;
    private TextView questionText;
    private LinearLayout optionsLayout;
    private Button nextButton;
    private ConstraintLayout quizLayout;  // The root layout to change background color

    // Array to hold the user's selected answers
    private int[] userAnswers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        // Initialize the quiz data from strings.xml
        quizQuestions = getResources().getStringArray(R.array.quiz_questions);
        quizOptions = new String[][]{
                getResources().getStringArray(R.array.quiz_options_1),
                getResources().getStringArray(R.array.quiz_options_2),
                getResources().getStringArray(R.array.quiz_options_3),
                getResources().getStringArray(R.array.quiz_options_4),
                getResources().getStringArray(R.array.quiz_options_5),
                getResources().getStringArray(R.array.quiz_options_6),
                getResources().getStringArray(R.array.quiz_options_7),
                getResources().getStringArray(R.array.quiz_options_8),
                getResources().getStringArray(R.array.quiz_options_9),
                getResources().getStringArray(R.array.quiz_options_10)
        };

        // Initialize UI elements
        questionText = findViewById(R.id.questionText);
        optionsLayout = findViewById(R.id.optionsLayout);
        nextButton = findViewById(R.id.nextButton);
        quizLayout = findViewById(R.id.quizLayout);

        // Initialize userAnswers array to store answers (assuming 4 questions)
        userAnswers = new int[quizQuestions.length];

        // Load the first question
        loadQuestion(currentQuestionIndex);

        // Set up the "Next" button click listener
        nextButton.setOnClickListener(v -> {
            // Move to next question
            currentQuestionIndex++;
            if (currentQuestionIndex < quizQuestions.length) {
                loadQuestion(currentQuestionIndex);
            } else {
                // Quiz finished, show result
                showResults();
            }
        });
    }

    // Method to load a question and its options dynamically
    private void loadQuestion(int questionIndex) {
        // Set question text
        questionText.setText(quizQuestions[questionIndex]);

        // Clear previous options
        optionsLayout.removeAllViews();

        // Load options for the current question
        String[] options = quizOptions[questionIndex];
        for (int i = 0; i < options.length; i++) {
            RadioButton radioButton = new RadioButton(this);
            radioButton.setText(options[i]);

            // Save the answer index when an option is selected
            int finalI = i;  // Use final variable for listener
            radioButton.setOnClickListener(v -> userAnswers[questionIndex] = finalI);

            optionsLayout.addView(radioButton);
        }

        // Change background color dynamically based on question index
        changeBackgroundColor(questionIndex);
    }

    // Method to change background color for each question
    private void changeBackgroundColor(int questionIndex) {
        // Array of color resources
        int[] colors = {
                getResources().getColor(R.color.quiz_question_bg_1),
                getResources().getColor(R.color.quiz_question_bg_2),
                getResources().getColor(R.color.quiz_question_bg_3),
                getResources().getColor(R.color.quiz_question_bg_4),
                getResources().getColor(R.color.quiz_question_bg_5),
                getResources().getColor(R.color.quiz_question_bg_6),
                getResources().getColor(R.color.quiz_question_bg_7),
                getResources().getColor(R.color.quiz_question_bg_8),
                getResources().getColor(R.color.quiz_question_bg_9),
                getResources().getColor(R.color.quiz_question_bg_10),
        };

        // Ensure we do not go out of bounds if the number of questions exceeds the number of colors
        if (questionIndex < colors.length) {
            quizLayout.setBackgroundColor(colors[questionIndex]);
        } else {
            quizLayout.setBackgroundColor(colors[0]);  // Default to first color if out of bounds
        }
    }

    // Method to show the result based on user's answers
    private void showResults() {
        // Process answers and determine the best pet based on user selections
        int totalScore = calculateTotalScore();
        String resultMessage = determineBestPet(totalScore);

        // Start the ResultActivity with the result message
        Intent intent = new Intent(QuizActivity.this, ResultsActivity.class);
        intent.putExtra("resultMessage", resultMessage);
        startActivity(intent);
    }

    // Dummy method to calculate total score
    private int calculateTotalScore() {
        int score = 0;
        for (int answer : userAnswers) {
            score += answer;
        }
        return score;
    }

    // Method to determine the best pet based on the score
    private String determineBestPet(int totalScore) {
        if (totalScore >= 25) {
            return "You are most suitable for an Active Dog (e.g., Labrador)!";
        } else if (totalScore >= 20) {
            return "You are most suitable for a Dog!";
        } else if (totalScore >= 15) {
            return "You are most suitable for a Cat!";
        } else {
            return "You are most suitable for a Bird or Reptile!";
        }
    }
}