package com.example.adoptionapp2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;
import android.os.AsyncTask;

import androidx.appcompat.app.AppCompatActivity;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

public class AnimalDetailActivity extends AppCompatActivity {

    private Button exitButton;
    private int petId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal_detail);

        // Get the data passed through the Intent
        petId = getIntent().getIntExtra("petId", -1);
        String petName = getIntent().getStringExtra("petName");
        String petDetails = getIntent().getStringExtra("petDetails");
        String petDescription = getIntent().getStringExtra("petDescription");
        String petImageUri = getIntent().getStringExtra("petImage");
        String petNeutered = getIntent().getStringExtra("petNeutered");
        String petVaccinated = getIntent().getStringExtra("petVaccinated");

        // Initialize UI elements
        ImageButton exitButton = findViewById(R.id.ic_exit);
        TextView petNameTextView = findViewById(R.id.petNameTextView);
        TextView petDetailsTextView = findViewById(R.id.petDetailsTextView);
        TextView petDescriptionTextView = findViewById(R.id.petDescriptionTextView);
        TextView petNeuteredTextView = findViewById(R.id.petNeuteredTextView);
        TextView petVaccinatedTextView = findViewById(R.id.petVaccinatedTextView);
        ImageView petImageView = findViewById(R.id.petImageView);
        Button adoptButton = findViewById(R.id.adoptButton);

        // Set the data to the UI elements
        petNameTextView.setText(petName);
        petDetailsTextView.setText(petDetails);

        if (petDescription != null && !petDescription.isEmpty()) {
            petDescriptionTextView.setText(petDescription);
        } else {
            petDescriptionTextView.setText("No description available");
        }

        if ("Yes".equalsIgnoreCase(petNeutered)) {
            petNeuteredTextView.setText("Neutered");
            petNeuteredTextView.setVisibility(View.VISIBLE);
        } else {
            petNeuteredTextView.setVisibility(View.GONE);
        }

        if ("Yes".equalsIgnoreCase(petVaccinated)) {
            petVaccinatedTextView.setText("Vaccinated");
            petVaccinatedTextView.setVisibility(View.VISIBLE);
        } else {
            petVaccinatedTextView.setVisibility(View.GONE);
        }

        // Load image from path or URI
        if (petImageUri != null && !petImageUri.isEmpty()) {
            try {
                // Check if it's a file path or URI
                if (petImageUri.startsWith("/")) {
                    // It's a file path
                    petImageView.setImageURI(Uri.fromFile(new java.io.File(petImageUri)));
                } else {
                    // It's a URI
                    Uri imageUri = Uri.parse(petImageUri);
                    petImageView.setImageURI(imageUri);
                }
            } catch (Exception e) {
                petImageView.setImageResource(R.drawable.ic_default_pet_image);
            }
        } else {
            petImageView.setImageResource(R.drawable.ic_default_pet_image);
        }

        exitButton.setOnClickListener(v -> {
            // Navigate back to the Dogs Dashboard activity
            Intent intent = new Intent(AnimalDetailActivity.this, DashboardActivity.class);
            startActivity(intent);
            finish();  // Optionally close the current activity
        });

        // Set up the "Request Adopt" button click listener
        adoptButton.setOnClickListener(v -> {
            if (petId == -1) {
                Toast.makeText(this, "Error: Animal ID not found", Toast.LENGTH_SHORT).show();
                return;
            }

            // Get logged-in user ID from SharedPreferences
            SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            int userId = prefs.getInt("userId", -1);

            if (userId == -1) {
                Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
                return;
            }

            // Save adoption request to database
            DatabaseHelper dbHelper = new DatabaseHelper(this);
            long result = dbHelper.insertAdoptionRequest(petId, userId, "Pending");

            if (result != -1) {
                // Get pet owner's user ID
                int ownerId = dbHelper.getPetOwnerId(petId);

                if (ownerId != -1) {
                    // Get pet owner's email
                    String ownerEmail = dbHelper.getUserEmail(ownerId);

                    // Get current user's email
                    String adopterEmail = dbHelper.getUserEmail(userId);

                    // Send email to pet owner
                    if (!ownerEmail.isEmpty()) {
                        sendEmail(ownerEmail, adopterEmail, petName);
                    }
                }

                Toast.makeText(this, "Adoption request submitted!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(AnimalDetailActivity.this, ThankYouActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Failed to submit adoption request", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void sendEmail(String ownerEmail, String adopterEmail, String petName) {
        new SendEmailTask().execute(ownerEmail, adopterEmail, petName);
    }

    private class SendEmailTask extends AsyncTask<String, Void, Boolean> {
        @Override
        protected Boolean doInBackground(String... params) {
            String ownerEmail = params[0];
            String adopterEmail = params[1];
            String petName = params[2];

            try {
                // Email configuration
                String host = "smtp.gmail.com";
                String port = "587";
                String fromEmail = "brobuyaowan123@gmail.com"; // Change this to your app's email
                String password = "skoanpeuxujtkczy"; // Change this to your app's password

                Properties props = new Properties();
                props.put("mail.smtp.host", host);
                props.put("mail.smtp.port", port);
                props.put("mail.smtp.auth", "true");
                props.put("mail.smtp.starttls.enable", "true");

                Session session = Session.getInstance(props, new javax.mail.Authenticator() {
                    protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
                        return new javax.mail.PasswordAuthentication(fromEmail, password);
                    }
                });

                Message message = new MimeMessage(session);
                message.setFrom(new InternetAddress(fromEmail));
                message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(ownerEmail));
                message.setSubject("Adoption Interest Notification");

                String emailBody = "Hi,\n\n" +
                        "We would like to inform you that " + adopterEmail +
                        " has expressed interest in adopting " + petName + ".\n\n" +
                        "If you would like to follow up or review the adoption request, kindly contact them.\n\n" +
                        "Thank you for using our platform!\n\n" +
                        "Have a great day.";

                message.setText(emailBody);

                Transport.send(message);
                return true;
            } catch (MessagingException e) {
                e.printStackTrace();
                return false;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean success) {
            if (success) {
                Toast.makeText(AnimalDetailActivity.this, "Email sent successfully!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(AnimalDetailActivity.this, "Failed to send email", Toast.LENGTH_SHORT).show();
            }
        }


    }
}
