package com.example.adoptionapp2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class ThankYouActivity extends AppCompatActivity {

    private Button okButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thank_you);  // Make sure this references your new layout

        // Initialize the "OK" button
        okButton = findViewById(R.id.okButton);

        // Set up the "OK" button click listener
        okButton.setOnClickListener(v -> {
            // Go back to the Dashboard (MainActivity)
            Intent intent = new Intent(ThankYouActivity.this, DashboardActivity.class);
            startActivity(intent);  // Start DashboardActivity
            finish();  // Optional: Close the ThankYouActivity to prevent users from going back to it
        });
    }
}
