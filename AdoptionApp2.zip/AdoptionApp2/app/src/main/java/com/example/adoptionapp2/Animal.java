package com.example.adoptionapp2;

public class Animal {
    private int id;
    private String name;
    private int age;
    private String gender;
    private String category;
    private String description;
    private String image; // URI or file path
    private String neutered;
    private String vaccinated;

    public Animal(int id, String name, int age, String gender, String category, String description, String image, String neutered, String vaccinated) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.category = category;
        this.description = description;
        this.image = image;
        this.neutered = neutered;
        this.vaccinated = vaccinated;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getGender() { return gender; }
    public String getCategory() { return category; }
    public String getDescription() { return description; }
    public String getImage() { return image; }
    public String getNeutered() { return neutered; }
    public String getVaccinated() { return vaccinated; }
}
